ServerEvents.recipes(event => {
    // Fix Create: Dreams & Desires' steel block recipe
    event.replaceInput({id:"create_dd:crafting/steel_block_from_compacting"}, "#forge:ingots/steel", "create_dd:steel_ingot")

    // Fix Epic Samurai's steel block recipe
    event.replaceInput({id:"epicsamurai:steel_block"}, "#forge:ingots/steel", "epicsamurai:steel_ingot")

    // Fix Epic Paladins' steel block recipe
    event.replaceInput({id:"epicpaladins:steel_block"}, "#forge:ingots/steel", "epicpaladins:steel_ingot")

    // Makes that only TFMG's steel is usable on TFMG recipes
    event.replaceInput({mod:"tfmg"}, "#forge:ingots/steel", "tfmg:steel_ingot")

    // Makes that you can't produce Create: Big Cannons' steel
    event.remove({output:"createbigcannons:basin_foundry_lid"})

    // Removes Epic Paladines' conflicting recipe with TFMG cast iron's recipe
    event.remove({id:"epicsamurai:steel_ingot_create_compat"})
})