ServerEvents.recipes(event => {
    // Asurine
    event.recipes.create.mixing(["create:asurine"], [Fluid.water(250), "minecraft:stone"])

    // Blaze cake base
    event.recipes.create.compacting(["create:blaze_cake_base"], ["4x minecraft:stick", "create:andesite_alloy", "minecraft:red_dye"])

    // Coal
    event.recipes.create.pressing("minecraft:coal", "minecraft:charcoal")

    // Copper
    event.recipes.create.milling(["create:crushed_raw_copper", Item.of("create:crushed_raw_copper").withChance(0.3)], "create:veridium")
    event.recipes.create.mixing("minecraft:copper_ingot", [Fluid.lava(50), "create:crushed_raw_copper"])

    // Clay
    event.recipes.create.mixing("minecraft:clay", [Fluid.water(250), "minecraft:dirt"])

    // Crimsite
    event.custom({
        type: "create_mechanical_extruder:extruding",
        ingredients: [
          {
            fluid: "create_dd:strawberry_milkshake",
            amount: 1000
          },
          {
            fluid: "minecraft:lava",
            amount: 1000
          }
        ],
        result: {
          item: "create:crimsite"
        }
      })

    // Gold
    event.recipes.create.filling("minecraft:magma_block", [Fluid.lava(250), "minecraft:cobblestone"])
    event.recipes.create.splashing("minecraft:netherrack", "minecraft:magma_block")
    event.recipes.create.mixing("chipped:eroded_nether_bricks", ["minecraft:netherrack", "minecraft:dripstone_block"])
    event.recipes.create.milling("3x minecraft:gold_nugget", "chipped:eroded_nether_bricks")

    // Key Panel
    event.shaped("securitycraft:keypad_item", [
      "AAA",
      "ABA",
      "AAA"
    ], {
        A: "minecraft:stone_button",
        B: "minecraft:heavy_weighted_pressure_plate"
      }
    )

    // Nitrate Dust
    event.blasting("tfmg:air_bucket", "minecraft:bucket")
    event.custom({
      type: "create_new_age:energising",
      energy_needed: 3750,
      ingredients: [
        {item: "tfmg:air_bucket"}
      ],
      results: [
        {item: "kubejs:nitrogen_oxide_tank"}
      ]
    })
    event.recipes.create.splashing("kubejs:nitrogen_dioxide_tank", "kubejs:nitrogen_oxide_tank")
    event.recipes.create.mixing(["2x tfmg:nitrate_dust", "minecraft:bucket"], [Fluid.water(1000), "kubejs:nitrogen_dioxide_tank"]).heated()


    // Notch's apple
    event.shaped("minecraft:enchanted_golden_apple", [
      "AAA",
      "ABA",
      "AAA"
    ], {
      A: "minecraft:gold_block",
      B: "minecraft:apple"      
      }
    )

    // Obsidian
    event.recipes.create.mixing("minecraft:obsidian", [Fluid.water(1000), Fluid.lava(1000)])

    // Ochrum
    event.custom({
        type: "create_mechanical_extruder:extruding",
        ingredients: [
          {
            fluid: "create_dd:glowberry_milkshake",
            amount: 1000
          },
          {
            fluid: "minecraft:lava",
            amount: 1000
          }
        ],
        result: {
          item: "create:ochrum"
        }
      })
    
    // Radiant drill
    event.shaped("create_dd:radiant_drill", [
      " A ",
      "ABA",
      " C "
    ], {
      A: "create_dd:refined_radiance",
      B: "minecraft:prismarine",
      C: "#forge:steel/ingots"
    }
    )

    // Raw iron
    event.recipes.create.mixing("minecraft:raw_iron", ["minecraft:basalt", "minecraft:coal", "tfmg:limesand"]).heated()

    // Redstone
    event.recipes.create.mixing("3x minecraft:redstone", ["create:small_ochrum_brick_slab", "create:small_crimsite_bricks", "minecraft:copper_ingot"]).superheated()

    // Thorium
    event.recipes.create.milling(Item.of("create_new_age:radioactive_thorium").withChance(0.2), "create_new_age:thorium")
    event.recipes.create.compacting("create_new_age:thorium", ["create:asurine", "minecraft:dripstone_block"]).superheated()

    // Veridium
    event.custom({
        type: "create_mechanical_extruder:extruding",
        ingredients: [
          {
            fluid: "create_dd:caramel_milkshake",
            amount: 1000
          },
          {
            fluid: "minecraft:lava",
            amount: 1000
          }
        ],
        result: {
          item: "create:veridium"
        }
      })

    // Zinc
    event.recipes.create.crushing([Item.of("3x create:zinc_nugget").withChance(0.8), Item.of("create:crushed_raw_zinc").withChance(0.2)], "create:layered_asurine").processingTime(150)
})