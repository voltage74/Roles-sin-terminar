StartupEvents.registry('item', event => {
    event.create("nitrogen_oxide_tank").texture("tfmg:item/neon_bucket")
    event.create("nitrogen_dioxide_tank").texture("tfmg:item/neon_bucket")
})