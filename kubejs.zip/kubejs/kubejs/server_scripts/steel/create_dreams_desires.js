ServerEvents.recipes(event => {
    // Fixes Create: Dreams & Desires' steel block recipe
    event.replaceInput({id:"create_dd:crafting/steel_block_from_compacting"}, "#forge:ingots/steel", "create_dd:steel_ingot")

    // Changes the recipe to get Create: Dreams & Desires' steel ingot
    event.remove({id: "create_dd:compacting/steel_ingot"})
    event.blasting("create_dd:steel_ingot", "minecraft:iron_ingot")

    event.replaceInput(
        {id: "create_dd:crafting/steel_ingot_from_decompacting"},
        "#createbigcannons:block_steel",
        "create_dd:steel_block"
    )

    event.replaceInput(
        {id: "create_dd:crafting/steel_ingot_from_compacting"},
        "#createbigcannons:nugget_steel",
        "create_dd:steel_nugget"
    )

    event.replaceInput(
        {id: "create_dd:crafting/steel_nugget_from_decompacting"},
        "#forge:ingots/steel",
        "create_dd:steel_ingot"
    )

    event.replaceInput(
        {id: "create_dd:pressing/steel_ingot"},
        "#forge:ingots/steel",
        "create_dd:steel_ingot"
    )
})