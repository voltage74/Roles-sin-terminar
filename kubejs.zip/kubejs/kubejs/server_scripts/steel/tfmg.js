ServerEvents.recipes(event => {
    // Only TFMG's steel can be used in TFMG's recipes
    event.replaceInput({mod:"tfmg"}, "#forge:ingots/steel", "tfmg:steel_ingot")

    // Change the production of TFMG's molten steel to Tinkers Construct's molten steel
    event.remove({id:"tfmg:industrial_blasting/steel"})
    event.custom({
        "type": "tfmg:industrial_blasting",
        "ingredients": [
          {
            "item": "tfmg:blasting_mixture"
          }
        ],
        "processingTime": 200,
        "results": [
          {
            "amount": 111,
            "fluid": "tconstruct:molten_steel"
          },
          {
            "amount": 75,
            "fluid": "tfmg:molten_slag"
          }
        ]
      })
    
    // Change the liquid to get TFMG's steel to Tinkers Construct's molten steel
    event.remove("tfmg:casting/steel")
    event.custom({
        "type": "tfmg:casting",
        "ingredients": [
          {
            "fluid": "tconstruct:molten_steel",
            "amount": 1
          }
        ],
        "processingTime": 300,
        "results": [
          {
            "count": 1,
            "item": "tfmg:steel_ingot"
          }
        ,
          {
            "count": 1,
            "item": "tfmg:steel_block"
          }
        ]
      })
})