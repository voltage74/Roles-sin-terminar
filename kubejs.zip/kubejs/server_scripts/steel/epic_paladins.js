ServerEvents.recipes(event => {
    // Deletes Epic Paladins' steel
    event.remove({output: "epicpaladins:steel_ingot"})
    event.remove({output: "epicpaladins:steel_block"})
    event.remove({output: "epicpaladins:steel_nugget"})

    // Makes so Epic Paladins uses Create: Dreams & Desires' steel
    event.replaceInput({mod: "epicpaladins"}, "#forge:ingots/steel", "create_dd:steel_ingot")
    event.replaceInput({mod: "epicpaladins"}, "#createbigcannons:nugget_steel", "create_dd:steel_nugget")
})