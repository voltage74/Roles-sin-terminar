ServerEvents.recipes(event => {
    // Deletes Create: Big Cannons' molten steel recipe
    event.remove({id: "createbigcannons:melting/melt_steel_block"})
    event.remove({id: "createbigcannons:melting/melt_steel_ingot"})
    event.remove({id: "createbigcannons:melting/melt_steel_nugget"})
})