ServerEvents.recipes(event => {
    // Deletes Create: Nuclear's Steel
    event.remove({output: "createnuclear:steel_ingot"})
    event.remove({output: "createnuclear:steel_block"})
    event.remove({output: "createnuclear:steel_nugget"})
    event.replaceInput({mod:"createnuclear"}, "createnuclear:steel_ingot", "tfmg:steel_ingot")

    // Make a recipe to get steel nuggets
    event.shapeless("tfmg:steel_ingot", "9x createnuclear:steel_nugget")
    event.shapeless("9x createnuclear:steel_nugget", "tfmg:steel_ingot")
})