ServerEvents.recipes(event => {
    // Deletes Samurai Dynasty's steel
    event.remove({output: "samurai_dynasty:steel_ingot"})
    event.remove({output: "samurai_dynasty:steel_block"})
    event.remove({output: "samurai_dynasty:steel_nugget"})

    // Makes so Samurai Dynasty uses Create: Dreams & Desires' steel
    event.replaceInput({mod: "samurai_dynasty"}, "#forge:ingots/steel", "create_dd:steel_ingot")
    event.replaceInput({mod: "samurai_dynasty"}, "#createbigcannons:nugget_steel", "create_dd:steel_nugget")
})