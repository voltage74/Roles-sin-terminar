ServerEvents.recipes(event => {
    // Makes Create: Nuclear compatible with TFMG's lead
    event.replaceInput({mod: "createnuclear"}, "createnuclear:lead_ingot", "#forge:ingots/lead")
})