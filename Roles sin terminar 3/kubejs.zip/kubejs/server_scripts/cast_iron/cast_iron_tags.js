ServerEvents.tags('item', event => {
    // Removes Create: Big Cannons' cast iron
    event.removeAll("forge:ingots/cast_iron")
    event.add("forge:ingots/cast_iron", "tfmg:cast_iron_ingot")

    event.removeAll("createbigcannons:ingot_cast_iron")
    event.add("createbigcannons:ingot_cast_iron", "tfmg:cast_iron_ingot")

    event.removeAll("createbigcannons:block_cast_iron")
    event.add("createbigcannons:block_cast_iron", "tfmg:cast_iron_block")
})