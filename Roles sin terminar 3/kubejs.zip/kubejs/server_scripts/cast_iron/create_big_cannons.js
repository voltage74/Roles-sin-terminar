ServerEvents.recipes(event => {
    event.replaceOutput({id: "createbigcannons:cast_iron_ingot_from_nuggets"}, "createbigcannons:cast_iron_ingot", "tfmg:cast_iron_ingot")
    
    event.remove({output: "createbigcannons:cast_iron_block"})
    event.remove({output: "createbigcannons:cast_iron_ingot"})
    
    event.remove({input: "createbigcannons:cast_iron_block"})
    event.remove({input: "createbigcannons:cast_iron_ingot"})
})