ServerEvents.recipes(event => {
    // Establishes relation with Create: Big Cannons' cast iron nuggets and TFMG's cast iron ingot
    event.shapeless("9x createbigcannons:cast_iron_nugget", "tfmg:cast_iron_ingot")
})