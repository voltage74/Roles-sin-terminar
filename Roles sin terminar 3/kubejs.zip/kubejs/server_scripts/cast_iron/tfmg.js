ServerEvents.recipes(event => {
    event.replaceInput({mod: "tfmg"}, "#forge:ingots/cast_iron", "tfmg:cast_iron_ingot")
})