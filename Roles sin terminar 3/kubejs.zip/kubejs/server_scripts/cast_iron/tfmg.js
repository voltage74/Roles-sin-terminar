ServerEvents.recipes(event => {
    event.shapeless("9x createbigcannons:cast_iron_nugget", "tfmg:cast_iron_ingot")
})