ServerEvents.recipes(event => {
    event.replaceInput({mod: "createbigcannons"}, "#forge:ingots/cast_iron", "tfmg:cast_iron_ingot")
    event.replaceOutput({id: "createbigcannons:cast_iron_ingot_from_nuggets"}, "createbigcannons:cast_iron_ingot", "tfmg:cast_iron_ingot")
    
    event.remove({output: "createbigcannons:cast_iron_block"})
    event.remove({output: "createbigcannons:cast_iron_ingot"})
    
    event.remove({input: "createbigcannons:cast_iron_block"})

    event.remove({id: "createbigcannons:melting/melt_cast_iron_ingot"})
    event.custom({
        "type": "createbigcannons:melting",
        "heatRequirement": "heated",
        "ingredients": [
          {
            "item": "tfmg:cast_iron_ingot"
          }
        ],
        "processingTime": 180,
        "results": [
          {
            "amount": 90,
            "fluid": "createbigcannons:molten_cast_iron"
          }
        ]
      })

    event.remove({id: "createbigcannons:melting/melt_cast_iron_block"})
    event.custom({
        "type": "createbigcannons:melting",
        "heatRequirement": "heated",
        "ingredients": [
          {
            "item": "tfmg:cast_iron_block"
          }
        ],
        "processingTime": 1620,
        "results": [
          {
            "amount": 810,
            "fluid": "createbigcannons:molten_cast_iron"
          }
        ]
      })
})