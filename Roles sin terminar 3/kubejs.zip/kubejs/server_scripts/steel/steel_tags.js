ServerEvents.tags('item', event => {
    // Steel nuggets
    event.removeAll("createbigcannons:nugget_steel")
    event.add("createbigcannons:nugget_steel", "ad_astra:steel_nugget")

    event.removeAll("forge:nuggets/steel")
    event.add("forge:nuggets/steel", "ad_astra:steel_nugget")

    event.removeAll("ad_astra:steel_nuggets")
    event.add("ad_astra:steel_nuggets", "ad_astra:steel_nugget")

    // Steel ingots
    event.removeAll("createbigcannons:ingot_steel")
    event.add("createbigcannons:ingot_steel", "tfmg:steel_ingot")

    event.removeAll("forge:ingots/steel")
    event.add("forge:ingots/steel", "tfmg:steel_ingot")

    event.removeAll("ad_astra:steel_ingots")
    event.add("ad_astra:steel_ingots", "tfmg:steel_ingot")

    // Steel blocks
    event.removeAll("createbigcannons:block_steel")
    event.add("createbigcannons:block_steel", "tfmg:steel_block")

    event.removeAll("forge:storage_blocks/steel")
    event.add("forge:storage_blocks/steel", "tfmg:steel_block")

    event.removeAll("ad_astra:steel_blocks")
    event.add("ad_astra:steel_blocks", "tfmg:steel_block")

    // Steel plates
    event.removeAll("createbigcannons:sheet_steel")
    event.add("createbigcannons:sheet_steel", "tfmg:heavy_plate")

    event.removeAll("forge:plates/steel")
    event.add("forge:plates/steel", "tfmg:heavy_plate")

    event.removeAll("ad_astra:steel_plates")
    event.add("ad_astra:steel_plates", "tfmg:heavy_plate")
})