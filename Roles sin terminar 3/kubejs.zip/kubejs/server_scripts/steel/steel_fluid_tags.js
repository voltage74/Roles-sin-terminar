ServerEvents.tags('fluid', event => {
    event.removeAll("forge:molten_steel")
    event.add("forge:molten_steel", "tconstruct:molten_steel")

    event.removeAll("tconstruct:molten_steel")
    event.add("tconstruct:molten_steel", "tconstruct:molten_steel")
})