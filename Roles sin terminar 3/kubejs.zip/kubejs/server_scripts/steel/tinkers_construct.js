ServerEvents.recipes(event => {
    // Removes recipes to get back the items melted to get TFMG's steel and Ad Astra's nuggets
    event.remove({id:"tconstruct:smeltery/casting/metal/steel/ingot_gold_cast"})
    event.remove({id:"tconstruct:smeltery/casting/metal/steel/ingot_sand_cast"})
    event.remove({id:"tconstruct:smeltery/casting/metal/steel/nugget_gold_cast"})
    event.remove({id:"tconstruct:smeltery/casting/metal/steel/nugget_sand_cast"})

    // Ingot
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/multi_use/ingot"
        },
        "cooling_time": 65,
        "fluid": {
          "amount": 90,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "tfmg:steel_ingot"
        }
      })
    
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/single_use/ingot"
        },
        "cast_consumed": true,
        "cooling_time": 65,
        "fluid": {
          "amount": 90,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "tfmg:steel_ingot"
        }
      })
    
    // Heavy plate
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/multi_use/plate"
        },
        "conditions": [
          {
            "type": "mantle:tag_filled",
            "tag": "forge:plates/steel"
          }
        ],
        "cooling_time": 65,
        "fluid": {
          "amount": 90,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "tfmg:heavy_plate"
        }
      })
    
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/single_use/plate"
        },
        "cast_consumed": true,
        "conditions": [
          {
            "type": "mantle:tag_filled",
            "tag": "forge:plates/steel"
          }
        ],
        "cooling_time": 65,
        "fluid": {
          "amount": 90,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "tfmg:heavy_plate"
        }
      })
    
    // Nugget
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/multi_use/nugget"
        },
        "cooling_time": 22,
        "fluid": {
          "amount": 10,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "ad_astra:steel_nugget"
        }
      })
    
    event.custom({
        "type": "tconstruct:casting_table",
        "cast": {
          "tag": "tconstruct:casts/single_use/nugget"
        },
        "cast_consumed": true,
        "cooling_time": 22,
        "fluid": {
          "amount": 10,
          "tag": "forge:molten_steel"
        },
        "result": {
          "item": "ad_astra:steel_nugget"
        }
      })
})