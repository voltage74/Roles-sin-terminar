ServerEvents.recipes(event => {
    // Fixing bugs with Ad Astra and Create: The Factory Must Grow
    event.replaceInput({id: "tconstruct:common/materials/steel_ingot_from_nuggets"}, "ad_astra:steel_nugget", "tconstruct:steel_nugget")
    event.replaceInput({id: "tconstruct:common/materials/steel_block_from_ingots"}, "tfmg:steel_block", "tconstruct:steel_nugget")

    // Give Tinkers' Construct's steel new recipes
    // Steel nugget
    event.shapeless("tconstruct:steel_nugget", "ad_astra:steel_nugget")
    event.shapeless("ad_astra:steel_nugget", "tconstruct:steel_nugget")

    // Steel ingot
    event.shapeless("tconstruct:steel_ingot", "tfmg:steel_ingot")
    event.shapeless("tfmg:steel_ingot", "tconstruct:steel_ingot")

    // Steel block
    event.shapeless("tconstruct:steel_block", "tfmg:steel_block")
    event.shapeless("tfmg:steel_block", "tconstruct:steel_block")
})