ServerEvents.recipes(event => {
    // Deletes Samurai Dynasty's steel
    event.remove({input: "samurai_dynasty:steel_ingot"})
    event.remove({input: "samurai_dynasty:steel_block"})
    event.remove({input: "samurai_dynasty:steel_nugget"})
    
    event.remove({output: "samurai_dynasty:steel_ingot"})
    event.remove({output: "samurai_dynasty:steel_block"})
    event.remove({output: "samurai_dynasty:steel_nugget"})
})