ServerEvents.recipes(event => {
    // Changes the Create: Big Cannons' molten steel to the Tinkers Construct's molten steel
    event.remove({id: "createbigcannons:melting/melt_steel_block"})
    event.custom({
        "type": "createbigcannons:melting",
        "heatRequirement": "heated",
        "ingredients": [
          {
            "tag": "createbigcannons:block_steel"
          }
        ],
        "processingTime": 1620,
        "results": [
          {
            "amount": 810,
            "fluid": "tconstruct:molten_steel"
          }
        ]
      })

    event.remove({id: "createbigcannons:melting/melt_steel_ingot"})
    event.custom({
        "type": "createbigcannons:melting",
        "heatRequirement": "heated",
        "ingredients": [
          {
            "tag": "createbigcannons:ingot_steel"
          }
        ],
        "processingTime": 180,
        "results": [
          {
            "amount": 90,
            "fluid": "tconstruct:molten_steel"
          }
        ]
      })

    event.remove({id: "createbigcannons:melting/melt_steel_nugget"})
    event.custom({
        "type": "createbigcannons:melting",
        "heatRequirement": "heated",
        "ingredients": [
          {
            "tag": "createbigcannons:nugget_steel"
          }
        ],
        "processingTime": 20,
        "results": [
          {
            "amount": 10,
            "fluid": "tconstruct:molten_steel"
          }
        ]
      })
})