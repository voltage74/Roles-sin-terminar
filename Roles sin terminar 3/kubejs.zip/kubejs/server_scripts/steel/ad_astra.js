ServerEvents.recipes(event => {
    // Establishes relation with Ad Astra's steel nuggets and TFMG's steel ingot
    event.shapeless("9x ad_astra:steel_nugget", "tfmg:steel_ingot")
    event.shapeless("tfmg:steel_ingot", "9x ad_astra:steel_nugget")

    // Deletes Ad Astra's steel
    event.remove({input: "ad_astra:steel_ingot"})
    event.remove({input: "ad_astra:steel_block"})
    event.remove({input: "ad_astra:steel_plate"})
    
    event.remove({output: "ad_astra:steel_ingot"})
    event.remove({output: "ad_astra:steel_block"})
    event.remove({output: "ad_astra:steel_plate"})

    event.remove({id: "ad_astra:alloying/steel_ingot_from_alloying_iron_ingot_and_coals"})

    // Changes the Ad Astra's steel plate to TFMG's steel plate
    event.remove({id: "ad_astra:compressing/steel_plate_from_compressing_steel_blocks"})
    event.custom({
        "type": "ad_astra:compressing",
        "cookingtime": 800,
        "energy": 20,
        "ingredient": {
          "tag": "ad_astra:steel_blocks"
        },
        "result": {
          "count": 9,
          "id": "tfmg:heavy_plate"
        }
      })

    event.remove({id: "ad_astra:compressing/steel_plate_from_compressing_steel_ingots"})
    event.custom({
        "type": "ad_astra:compressing",
        "cookingtime": 100,
        "energy": 20,
        "ingredient": {
          "tag": "ad_astra:steel_ingots"
        },
        "result": {
          "count": 1,
          "id": "tfmg:heavy_plate"
        }
      })
})