ServerEvents.recipes(event => {
    // Makes Create: Nuclear only use TFMG's steel
    event.replaceInput({mod:"createnuclear"}, "createnuclear:steel_ingot", "tfmg:steel_ingot")
    event.replaceInput({mod:"createnuclear"}, "#forge:nuggets/steel", "createnuclear:steel_nugget")
    event.replaceInput({id:"createnuclear:crafting/steel_block_from_compacting"}, "tfmg:steel_ingot", "createnuclear:steel_ingot")

    // Make a recipe to get steel nuggets
    event.shapeless("tfmg:steel_ingot", "9x createnuclear:steel_nugget")
    event.shapeless("9x createnuclear:steel_nugget", "tfmg:steel_ingot")
})