ServerEvents.recipes(event => {
    // Deletes Create: Nuclear steel
    event.remove({input: "createnuclear:steel_ingot"})
    event.remove({input: "createnuclear:steel_block"})
    event.remove({input: "createnuclear:steel_nugget"})
    
    event.remove({output: "createnuclear:steel_ingot"})
    event.remove({output: "createnuclear:steel_block"})
    event.remove({output: "createnuclear:steel_nugget"})
})