ServerEvents.recipes(event => {
    // Deletes Epic Paladins' steel
    event.remove({input: "epicpaladins:steel_ingot"})
    event.remove({input: "epicpaladins:steel_block"})
    event.remove({input: "epicpaladins:steel_nugget"})
    
    event.remove({output: "epicpaladins:steel_ingot"})
    event.remove({output: "epicpaladins:steel_block"})
    event.remove({output: "epicpaladins:steel_nugget"})
})