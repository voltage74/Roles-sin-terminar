ServerEvents.tags('item', event => {
    // Deletes Ad Astra iron plate
    event.removeAll("forge:plates/iron")
    event.add("forge:plates/iron", "create:iron_sheet")

    event.removeAll("createbigcannons:sheet_iron")
    event.add("createbigcannons:sheet_iron", "create:iron_sheet")

    event.removeAll("ad_astra:iron_plates")
    event.add("ad_astra:iron_plates", "create:iron_sheet")

    event.removeAll("railways:internal/plates/iron_plates")
    event.add("railways:internal/plates/iron_plates", "create:iron_sheet")
})