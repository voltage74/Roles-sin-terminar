ServerEvents.recipes(event => {
    // Changes the output to Create's iron sheet
    event.remove("ad_astra:compressing/iron_plate_from_compressing_iron_ingot")
    event.custom({
        "type": "ad_astra:compressing",
        "cookingtime": 100,
        "energy": 20,
        "ingredient": {
          "item": "minecraft:iron_ingot"
        },
        "result": {
          "count": 1,
          "id": "create:iron_sheet"
        }
      })

    event.remove("ad_astra:compressing/iron_plate_from_compressing_iron_block")
    event.custom({
        "type": "ad_astra:compressing",
        "cookingtime": 800,
        "energy": 20,
        "ingredient": {
          "item": "minecraft:iron_block"
        },
        "result": {
          "count": 9,
          "id": "create:iron_sheet"
        }
      })
})