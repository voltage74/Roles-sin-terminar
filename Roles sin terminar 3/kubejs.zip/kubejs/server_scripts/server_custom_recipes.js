ServerEvents.recipes(event => {
    // Asurine
    event.recipes.create.mixing(["create:asurine"], [Fluid.water(250), "minecraft:stone"])

    // Blaze cake base
    event.recipes.create.compacting(["create:blaze_cake_base"], ["2x minecraft:quartz", "minecraft:clay_ball", "croptopia:salt", "create:cinder_flour"])

    // Coal
    event.recipes.create.pressing("minecraft:coal", "minecraft:charcoal")

    // Copper
    event.recipes.create.milling(["create:crushed_raw_copper", Item.of("create:crushed_raw_copper").withChance(0.3)], "create:veridium")
    event.recipes.create.mixing("minecraft:copper_ingot", [Fluid.lava(50), "create:crushed_raw_copper"])

    // Clay
    event.remove({id: "create:splashing/sand"})
    event.recipes.create.splashing(Item.of("minecraft:clay_ball").withChance(0.8), "minecraft:sand")

    // Key Panel
    event.shaped("securitycraft:keypad_item", [
      "AAA",
      "ABA",
      "AAA"
    ], {
        A: "minecraft:stone_button",
        B: "minecraft:heavy_weighted_pressure_plate"
      }
    )

    // Notch's apple
    event.shaped("minecraft:enchanted_golden_apple", [
      "AAA",
      "ABA",
      "AAA"
    ], {
      A: "minecraft:gold_block",
      B: "minecraft:apple"      
      }
    )

    // Obsidian
    event.recipes.create.mixing("minecraft:obsidian", [Fluid.water(1000), Fluid.lava(1000)])

    // Raw iron
    event.recipes.create.mixing("minecraft:raw_iron", ["minecraft:basalt", "minecraft:coal", "tfmg:limesand"]).heated()

    // Raw rubber
    event.remove("create_dd:mixing/raw_rubber")
    event.custom({
      type: "create:mixing",
      ingredients: [
        {
          fluid: "create_dd:sap",
          amount: 1000
        }
      ],
      results: [{
        item: "create_dd:raw_rubber",
        count: 4
      }]
    })

    // Redstone
    event.recipes.create.mixing("minecraft:redstone", ["minecraft:copper_ingot", "create:cinder_flour", Fluid.of("tfmg:liquid_plastic", 112)]).superheated()
    event.recipes.create.mixing("minecraft:redstone_block", ["minecraft:copper_block", "tfmg:cinderflourblock", Fluid.of("tfmg:liquid_plastic", 1000)]).superheated()

    // Veridium
    event.recipes.create.mixing("create:veridium", ["minecraft:diorite", "minecraft:flint", Fluid.lava(250)])

    // Zinc
    event.recipes.create.crushing([Item.of("3x create:zinc_nugget").withChance(0.8), Item.of("create:crushed_raw_zinc").withChance(0.2)], "create:asurine").processingTime(150)
})