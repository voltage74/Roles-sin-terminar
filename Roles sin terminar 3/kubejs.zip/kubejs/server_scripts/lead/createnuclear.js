ServerEvents.recipes(event => {
    // Makes Create: Nuclear compatible with TFMG's lead
    event.remove({output: "createnuclear:lead_block"})
    event.remove({input: "createnuclear:lead_block"})
})