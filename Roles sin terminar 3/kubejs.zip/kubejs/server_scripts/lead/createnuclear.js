ServerEvents.recipes(event => {
    // Makes Create: Nuclear compatible with TFMG's lead
    event.replaceInput({mod: "createnuclear"}, "#forge:ingots/lead", "createnuclear:lead_ingot")
    event.remove({output: "createnuclear:lead_block"})
    event.remove({input: "createnuclear:lead_block"})
})