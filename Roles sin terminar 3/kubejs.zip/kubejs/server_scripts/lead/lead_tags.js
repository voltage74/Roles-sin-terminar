ServerEvents.tags('item', event => {
    // Removes TFMG's lead ingot from recipes
    event.removeAll("forge:ingots/lead")
    event.add("forge:ingots/lead", "createnuclear:lead_ingot")
})