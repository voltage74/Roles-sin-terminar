ServerEvents.recipes(event => {
    // Replaces TFMG's lead ingots with Create: Nuclear lead ingots
    event.replaceOutput({mod: "tfmg"}, "tfmg:lead_ingot", "createnuclear:lead_ingot")
    event.replaceInput({mod: "tfmg"}, "tfmg:lead_ingot", "createnuclear:lead_ingot")
})