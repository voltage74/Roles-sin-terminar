ServerEvents.recipes(event => {
    event.replaceInput({mod: "tfmg"}, "#forge:ingots/lead", "createnuclear:lead_ingot")
    event.replaceOutput({mod: "tfmg"}, "tfmg:lead_ingot", "createnuclear:lead_ingot")
})