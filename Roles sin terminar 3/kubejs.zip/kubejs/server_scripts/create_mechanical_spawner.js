ServerEvents.recipes(event => {
    // Removes all mob's recipes of Create: Mechanical Spawner
    event.remove({mob:[
        "minecraft:bat",
        "minecraft:bee",
        "minecraft:blaze",
        "minecraft:chicken",
        "minecraft:cow",
        "minecraft:creeper",
        "minecraft:drowned", 
        "minecraft:enderman",
        "minecraft:evoker", 
        "minecraft:fox",
        "minecraft:ghast", 
        "minecraft:horse",
        "minecraft:magma_cube",
        "minecraft:panda",
        "minecraft:parrot",
        "minecraft:pig",
        "minecraft:pigling",
        "minecraft:rabbit",
        "minecraft:slime",
        "minecraft:spider",
        "minecraft:villager",
        "minecraft:witch",
        "minecraft:wither_skeleton",
        "minecraft:wolf"
    ]})

    // Random spawn fluid
    event.remove({id:"create_mechanical_spawner:mixing/spawn_fluid_random_legacy"})
    event.recipes.create.mixing(Fluid.of("create_mechanical_spawner:spawn_fluid_random", 200), [Fluid.water(200), "minecraft:ender_pearl", "minecraft:coal"]).heated()

    // Blaze
    event.recipes.createMechanicalSpawnerSpawner(Fluid.of("create_mechanical_spawner:spawn_fluid_blaze", 100))
    .mob("minecraft:blaze")
    .processingTime(1000)
    .customLoot(
        "minecraft:blaze_rod"
    )

    // Creeper
    event.recipes.createMechanicalSpawnerSpawner(Fluid.of("create_mechanical_spawner:spawn_fluid_creeper", 100))
    .mob("minecraft:blaze")
    .processingTime(1000)
    .customLoot(
        "2x minecraft:gunpowder"
    )

    // Enderman
    event.recipes.createMechanicalSpawnerSpawner(Fluid.of("create_mechanical_spawner:spawn_fluid_enderman", 100))
    .mob("minecraft:enderman")
    .processingTime(1000)
    .customLoot(
        "minecraft:ender_pearl"
    )

    // Zombie
    event.recipes.createMechanicalSpawnerSpawner(Fluid.of("create_mechanical_spawner:spawn_fluid_zombie", 100))
    .mob("minecraft:blaze")
    .processingTime(1000)
    .customLoot(
        Item.of("minecraft:rotten_flesh").withChance(0.6)
    )
})