ServerEvents.recipes(event => {
    // Acacia log
    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 100), 
        Item.of("minecraft:stripped_acacia_log").withChance(0.4),
    ], 
        "minecraft:stripped_acacia_log"
    )

    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 100), 
        Item.of("minecraft:stripped_acacia_wood").withChance(0.4),
    ], 
        "minecraft:stripped_acacia_wood"
    )

    // Dark Oak log
    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 15), 
        Item.of("minecraft:stripped_dark_oak_log").withChance(0.4),
    ], 
        "minecraft:stripped_dark_oak_log"
    )

    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 15), 
        Item.of("minecraft:stripped_dark_oak_wood").withChance(0.4),
    ], 
        "minecraft:stripped_dark_oak_wood"
    )

    // Jungle log
    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_jungle_log").withChance(0.4),
    ], 
        "minecraft:stripped_jungle_log"
    )

    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_jungle_wood").withChance(0.4),
    ], 
        "minecraft:stripped_jungle_wood"
    )

    // Oak log
    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_oak_log").withChance(0.4),
    ], 
        "minecraft:stripped_oak_log"
    )

    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_oak_wood").withChance(0.4),
    ], 
        "minecraft:stripped_oak_wood"
    )

    // Spruce log
    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_spruce_log").withChance(0.4),
    ], 
        "minecraft:stripped_spruce_log"
    )

    event.recipes.create.emptying([
        Fluid.of("create_dd:sap", 25), 
        Item.of("minecraft:stripped_spruce_wood").withChance(0.4),
    ], 
        "minecraft:stripped_spruce_wood"
    )
})