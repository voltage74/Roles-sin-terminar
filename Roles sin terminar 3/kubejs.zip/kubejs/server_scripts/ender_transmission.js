ServerEvents.recipes(event => {
    let recipes_id_items = [
        ["createendertransmission:energy_transmitter", "create:shaft"],
        ["createendertransmission:item_transmitter", "create:chute"],
        ["createendertransmission:fluid_transmitter", "create:mechanical_pump"]
    ]

    recipes_id_items.forEach(id_and_items => {
        event.replaceInput(
            {id: id_and_items[0]},
            id_and_items[1],
            "minecraft:obsidian"
        )

        event.replaceInput(
            {id: id_and_items[0]},
            "minecraft:ender_eye",
            id_and_items[1]
        )

        event.replaceInput(
            {id: id_and_items[0]},
            "create:precision_mechanism",
            "minecraft:ender_eye"
        )
    })

    event.replaceInput(
        {id: "createendertransmission:fluid_transmitter"},
        "create:mechanical_pump",
        "create:fluid_tank"
    )
})