JEIEvents.hideItems(event => {
    let items = [
        "tfmg:lead_ingot",
        "createnuclear:lead_block"
    ]

    items.forEach(item =>{
        event.hide(item)
    })
})