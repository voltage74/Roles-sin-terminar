JEIEvents.hideFluids(event => {
    let fluids = [
        // Molten steel
        "createbigcannons:molten_steel",
        "tfmg:molten_steel"
    ]

    fluids.forEach(fluid =>{
        event.hide(fluid)
    })
})