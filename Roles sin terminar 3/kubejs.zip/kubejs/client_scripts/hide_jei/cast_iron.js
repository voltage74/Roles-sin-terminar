JEIEvents.hideItems(event => {
    let items = [
        "createbigcannons:cast_iron_ingot",
        "createbigcannons:cast_iron_block"
    ]

    items.forEach(item =>{
        event.hide(item)
    })
})