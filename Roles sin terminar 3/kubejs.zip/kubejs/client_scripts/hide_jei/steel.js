JEIEvents.hideItems(event => {
    let items = [
        // Steel nugget
        "createnuclear:steel_nugget",
        "epicpaladins:steel_nugget",
        "samurai_dynasty:steel_nugget",

        // Steel ingot
        "ad_astra:steel_ingot",
        "createnuclear:steel_ingot",
        "epicpaladins:steel_ingot",
        "samurai_dynasty:steel_ingot",

        // Steel block
        "ad_astra:steel_block",
        "createnuclear:steel_block",
        "epicpaladins:steel_block",
        "samurai_dynasty:steel_block",

        // Steel sheet
        "ad_astra:steel_plate",

        // Molten steel
        "createbigcannons:molten_steel_bucket",
        "tfmg:molten_steel_bucket"
    ]

    items.forEach(item =>{
        event.hide(item)
    })
})