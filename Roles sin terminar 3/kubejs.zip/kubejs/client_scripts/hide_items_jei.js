JEIEvents.hideItems(event => {
    let items = [
        // Ad Astra
        "ad_astra:steel_ingot",
        "ad_astra:steel_block",
        "ad_astra:steel_plate",

        // Create: Nuclear
        "create_nuclear:steel_nugget",
        "createnuclear:steel_ingot",
        "createnuclear:steel_block",
        
        // Epic Paladins
        "epicpaladins:steel_nugget",
        "epicpaladins:steel_ingot",
        "epicpaladins:steel_block",

        // Samurai Dynasty
        "samurai_dynasty:steel_nugget",
        "samurai_dynasty:steel_ingot",
        "samurai_dynasty:steel_block",
    ]

    items.forEach(item => {
        event.hide(item)
    });
})